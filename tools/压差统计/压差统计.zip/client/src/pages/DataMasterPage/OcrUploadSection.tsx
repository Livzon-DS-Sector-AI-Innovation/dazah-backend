import React, { useState, useCallback } from 'react';
import { Upload, Camera, CheckCircle2, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { createOcrTask } from '@client/src/api';
import { uploadFile } from '@/components/business-ui/api/files/service';

type UploadStatus = 'idle' | 'uploading' | 'success' | 'error';

const OcrUploadSection: React.FC<{ onTaskCreated?: () => void }> = ({ onTaskCreated }) => {
  const [status, setStatus] = useState<UploadStatus>('idle');
  const [message, setMessage] = useState<string>('');

  const handleUpload = useCallback(async (file: File) => {
    if (!file.type.startsWith('image/')) {
      toast.error('请上传图片文件');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast.error('图片大小不能超过10MB');
      return;
    }

    setStatus('uploading');
    setMessage('正在上传图片...');

    try {
      const uploadResult = await uploadFile(file);

      setMessage('正在创建识别任务...');
      await createOcrTask({ imageUrl: uploadResult.url });

      setStatus('success');
      setMessage('图片上传成功，OCR识别已在后台运行');
      toast.success('上传成功，识别任务已创建');
      onTaskCreated?.();

      setTimeout(() => {
        setStatus('idle');
        setMessage('');
      }, 3000);
    } catch (err: unknown) {
      logger.error('OCR上传失败', err);
      setStatus('error');
      setMessage('上传失败，请重试');
      toast.error('上传失败');
    }
  }, [onTaskCreated]);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleUpload(file);
    e.target.value = '';
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) handleUpload(file);
  };

  return (
    <Card className="rounded-lg shadow-sm">
      <CardContent className="p-4">
        <div
          className="flex flex-col items-center justify-center gap-3 rounded-lg border-2 border-dashed border-border p-6 transition-colors hover:border-primary/50 hover:bg-accent/30"
          onDragOver={(e: React.DragEvent) => e.preventDefault()}
          onDrop={handleDrop}
        >
          {status === 'idle' && (
            <>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Upload className="size-5" />
                <span className="text-sm">拖拽图片到此处，或点击下方按钮上传</span>
              </div>
              <div className="flex items-center gap-3">
                <label className="cursor-pointer">
                  <Button variant="outline" size="sm" asChild>
                    <span>
                      <Camera className="size-4 mr-1.5" />
                      拍照/选择图片
                    </span>
                  </Button>
                  <input type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFileInput} />
                </label>
                <label className="cursor-pointer">
                  <Button variant="outline" size="sm" asChild>
                    <span>
                      <Upload className="size-4 mr-1.5" />
                      选择文件
                    </span>
                  </Button>
                  <input type="file" accept="image/*" className="hidden" onChange={handleFileInput} />
                </label>
              </div>
            </>
          )}

          {status === 'uploading' && (
            <div className="flex items-center gap-2 text-primary">
              <div className="size-5 animate-spin rounded-full border-2 border-primary border-t-transparent" />
              <span className="text-sm">{message}</span>
            </div>
          )}

          {status === 'success' && (
            <div className="flex items-center gap-2 text-[hsl(152_60%_42%)]">
              <CheckCircle2 className="size-5" />
              <span className="text-sm">{message}</span>
            </div>
          )}

          {status === 'error' && (
            <div className="flex items-center gap-2 text-[hsl(4_75%_52%)]">
              <AlertCircle className="size-5" />
              <span className="text-sm">{message}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default OcrUploadSection;
