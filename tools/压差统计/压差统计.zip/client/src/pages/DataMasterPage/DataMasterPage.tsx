import React, { useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner';
import dayjs from 'dayjs';
import * as XLSX from 'xlsx-js-style';
import {
  FileDown,
  Search,
  ChevronLeft,
  ChevronRight,
  Trash2,
  Plus,
  Filter,
  CalendarIcon,
} from 'lucide-react';
import { CanRole } from '@lark-apaas/client-toolkit/auth';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from '@/components/ui/alert-dialog';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  getDataMasterList,
  createDataMaster,
  getDataMasterExport,
  deleteDataMaster,
  batchDeleteDataMaster,
} from '@client/src/api';
import type { DataMasterItem, DataMasterQuery, CreateDataMasterRequest } from '@shared/api.interface';
import { cn } from '@/lib/utils';
import OcrUploadSection from './OcrUploadSection';

const PAGE_SIZE = 20;

const SOURCE_LABELS: Record<string, string> = { manual: '手动录入', ocr: 'OCR识别' };

const BORDER_STYLE = {
  top: { style: 'thin' as const, color: { rgb: 'CCCCCC' } },
  bottom: { style: 'thin' as const, color: { rgb: 'CCCCCC' } },
  left: { style: 'thin' as const, color: { rgb: 'CCCCCC' } },
  right: { style: 'thin' as const, color: { rgb: 'CCCCCC' } },
};

const DataMasterPage: React.FC = () => {
  const [records, setRecords] = useState<DataMasterItem[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchText, setSearchText] = useState<string>('');
  const [filterSource, setFilterSource] = useState<string>('all');
  const [filterStartDate, setFilterStartDate] = useState<Date | undefined>();
  const [filterEndDate, setFilterEndDate] = useState<Date | undefined>();
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [actionLoading, setActionLoading] = useState<boolean>(false);
  const [deleteTarget, setDeleteTarget] = useState<{ type: 'single'; id: string } | { type: 'batch'; ids: string[] } | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState<boolean>(false);
  const [addDialogOpen, setAddDialogOpen] = useState<boolean>(false);
  const [addForm, setAddForm] = useState<CreateDataMasterRequest>({
    recordDate: dayjs().format('YYYY-MM-DD'),
    materialName: '',
    specModel: '',
    quantity: 0,
    unit: '',
    supplier: '',
    remark: '',
  });

  const buildParams = useCallback(
    (p: number): DataMasterQuery => {
      const params: DataMasterQuery = { page: p, pageSize: PAGE_SIZE };
      if (searchText.trim()) params.materialName = searchText.trim();
      if (filterSource !== 'all') params.source = filterSource;
      if (filterStartDate) params.startDate = dayjs(filterStartDate).format('YYYY-MM-DD');
      if (filterEndDate) params.endDate = dayjs(filterEndDate).format('YYYY-MM-DD');
      return params;
    },
    [searchText, filterSource, filterStartDate, filterEndDate],
  );

  const fetchRecords = useCallback(
    async (p: number) => {
      setLoading(true);
      try {
        const data = await getDataMasterList(buildParams(p));
        setRecords(data.items);
        setTotal(data.total);
      } catch {
        toast.error('获取数据失败');
      } finally {
        setLoading(false);
      }
    },
    [buildParams],
  );

  useEffect(() => { fetchRecords(page); }, [page, fetchRecords]);

  const handleSearch = () => { setPage(1); fetchRecords(1); };
  const handleReset = () => {
    setSearchText('');
    setFilterSource('all');
    setFilterStartDate(undefined);
    setFilterEndDate(undefined);
    setPage(1);
  };

  const openDeleteDialog = (target: { type: 'single'; id: string } | { type: 'batch'; ids: string[] }) => {
    setDeleteTarget(target);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    setActionLoading(true);
    try {
      if (deleteTarget?.type === 'single') {
        await deleteDataMaster(deleteTarget.id);
        toast.success('已删除');
      } else if (deleteTarget?.type === 'batch') {
        const result = await batchDeleteDataMaster(deleteTarget.ids);
        toast.success(`已删除 ${result.successCount} 条记录`);
        setSelectedIds(new Set());
      }
      setDeleteDialogOpen(false);
      fetchRecords(page);
    } catch { toast.error('删除失败'); }
    finally { setActionLoading(false); }
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedIds(new Set(records.map((r: DataMasterItem) => r.id)));
    } else {
      setSelectedIds(new Set());
    }
  };

  const handleSelectOne = (id: string, checked: boolean) => {
    const next = new Set(selectedIds);
    if (checked) next.add(id); else next.delete(id);
    setSelectedIds(next);
  };

  const handleExportExcel = async () => {
    try {
      toast.info('正在导出...');
      const params = buildParams(1);
      delete params.page;
      delete params.pageSize;
      const data = await getDataMasterExport(params);
      if (data.length === 0) { toast.error('暂无可导出的数据'); return; }

      const header = ['日期', '物料名称', '规格型号', '数量', '单位', '供应商', '备注', '来源', '创建人', '创建时间'];
      const rows = data.map((item) => [
        item.recordDate,
        item.materialName,
        item.specModel,
        item.quantity,
        item.unit,
        item.supplier,
        item.remark ?? '',
        SOURCE_LABELS[item.source] ?? item.source,
        item.creator,
        dayjs(item.createdAt).format('YYYY-MM-DD HH:mm:ss'),
      ]);

      const ws = XLSX.utils.aoa_to_sheet([header, ...rows]);
      const colWidths = header.map((h: string, colIdx: number) => {
        let maxLen = h.length * 2.5;
        for (const row of rows) {
          const cellLen = String(row[colIdx] ?? '').length * 2;
          if (cellLen > maxLen) maxLen = cellLen;
        }
        return { wch: Math.min(Math.max(maxLen + 2, 10), 40) };
      });
      ws['!cols'] = colWidths;

      const range = XLSX.utils.decode_range(ws['!ref'] ?? 'A1');
      for (let R = range.s.r; R <= range.e.r; R++) {
        for (let C = range.s.c; C <= range.e.c; C++) {
          const addr = XLSX.utils.encode_cell({ r: R, c: C });
          if (!ws[addr]) ws[addr] = { v: '' };
          if (R === 0) {
            ws[addr].s = { border: BORDER_STYLE, fill: { fgColor: { rgb: '4472C4' } }, font: { bold: true, color: { rgb: 'FFFFFF' }, sz: 11 }, alignment: { horizontal: 'center', vertical: 'center' } };
          } else {
            ws[addr].s = { border: BORDER_STYLE, alignment: { vertical: 'center' } };
          }
        }
      }

      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, '数据汇总');
      XLSX.writeFile(wb, `数据汇总_${dayjs().format('YYYY-MM-DD')}.xlsx`);
      toast.success(`已导出 ${data.length} 条记录`);
    } catch (err) {
      logger.error('导出失败', err);
      toast.error('导出失败');
    }
  };

  const handleAdd = async () => {
    if (!addForm.materialName.trim()) { toast.error('请填写物料名称'); return; }
    if (!addForm.recordDate) { toast.error('请选择日期'); return; }
    setActionLoading(true);
    try {
      await createDataMaster(addForm);
      toast.success('添加成功');
      setAddDialogOpen(false);
      setAddForm({ recordDate: dayjs().format('YYYY-MM-DD'), materialName: '', specModel: '', quantity: 0, unit: '', supplier: '', remark: '' });
      fetchRecords(page);
    } catch { toast.error('添加失败'); }
    finally { setActionLoading(false); }
  };

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const allSelected = records.length > 0 && records.every((r: DataMasterItem) => selectedIds.has(r.id));

  return (
    <div className="max-w-[1400px] mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-foreground">数据总表</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setAddDialogOpen(true)}>
            <Plus className="size-4 mr-1" />新增记录
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportExcel} disabled={total === 0}>
            <FileDown className="size-4 mr-1" />导出Excel
          </Button>
          <CanRole roles={['admin']} fallback={null}>
            <Button
              variant="outline"
              size="sm"
              disabled={selectedIds.size === 0 || actionLoading}
              onClick={() => openDeleteDialog({ type: 'batch', ids: Array.from(selectedIds) })}
              className="text-[hsl(4_75%_52%)] border-[hsl(4_75%_52%)] hover:bg-[hsl(4_70%_96%)]"
            >
              <Trash2 className="size-4 mr-1" />批量删除
            </Button>
          </CanRole>
        </div>
      </div>

      <OcrUploadSection onTaskCreated={() => fetchRecords(page)} />

      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col gap-3 md:flex-row md:flex-wrap md:items-end">
            <div className="flex flex-col gap-1.5 min-w-[180px]">
              <label className="text-xs text-muted-foreground">搜索物料名称</label>
              <div className="flex gap-1.5">
                <Input
                  placeholder="输入物料名称搜索"
                  value={searchText}
                  onChange={(e) => setSearchText(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') handleSearch(); }}
                />
                <Button size="icon" variant="outline" onClick={handleSearch}><Search className="size-4" /></Button>
              </div>
            </div>
            <div className="flex flex-col gap-1.5 min-w-[130px]">
              <label className="text-xs text-muted-foreground">来源</label>
              <Select value={filterSource} onValueChange={setFilterSource}>
                <SelectTrigger><SelectValue placeholder="全部" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  <SelectItem value="manual">手动录入</SelectItem>
                  <SelectItem value="ocr">OCR识别</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5 min-w-[150px]">
              <label className="text-xs text-muted-foreground">开始日期</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="justify-start text-left font-normal">
                    <CalendarIcon className="size-4 mr-1.5 opacity-50" />
                    {filterStartDate ? dayjs(filterStartDate).format('YYYY-MM-DD') : '选择日期'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar mode="single" selected={filterStartDate} onSelect={setFilterStartDate} />
                </PopoverContent>
              </Popover>
            </div>
            <div className="flex flex-col gap-1.5 min-w-[150px]">
              <label className="text-xs text-muted-foreground">结束日期</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="justify-start text-left font-normal">
                    <CalendarIcon className="size-4 mr-1.5 opacity-50" />
                    {filterEndDate ? dayjs(filterEndDate).format('YYYY-MM-DD') : '选择日期'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar mode="single" selected={filterEndDate} onSelect={setFilterEndDate} />
                </PopoverContent>
              </Popover>
            </div>
            <Button variant="ghost" size="default" onClick={handleReset}><Filter className="size-4 mr-1" />重置</Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="flex items-center justify-center py-16">
              <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
            </div>
          ) : records.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <Filter className="size-12 mb-3 opacity-40" />
              <p className="text-sm">暂无数据记录</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-accent/50">
                    <CanRole roles={['admin']} fallback={null}>
                      <TableHead className="w-12">
                        <Checkbox checked={allSelected} onCheckedChange={(checked) => handleSelectAll(checked === true)} />
                      </TableHead>
                    </CanRole>
                    <TableHead className="font-semibold">日期</TableHead>
                    <TableHead className="font-semibold min-w-[140px]">物料名称</TableHead>
                    <TableHead className="font-semibold min-w-[120px]">规格型号</TableHead>
                    <TableHead className="font-semibold text-right">数量</TableHead>
                    <TableHead className="font-semibold">单位</TableHead>
                    <TableHead className="font-semibold min-w-[140px]">供应商</TableHead>
                    <TableHead className="font-semibold min-w-[100px]">备注</TableHead>
                    <TableHead className="font-semibold">来源</TableHead>
                    <TableHead className="font-semibold">创建人</TableHead>
                    <CanRole roles={['admin']} fallback={null}>
                      <TableHead className="text-right font-semibold">操作</TableHead>
                    </CanRole>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {records.map((record: DataMasterItem, rowIdx: number) => (
                    <TableRow key={record.id} className={cn(rowIdx % 2 === 1 && 'bg-muted/30')}>
                      <CanRole roles={['admin']} fallback={null}>
                        <TableCell>
                          <Checkbox checked={selectedIds.has(record.id)} onCheckedChange={(checked) => handleSelectOne(record.id, checked === true)} />
                        </TableCell>
                      </CanRole>
                      <TableCell className="tabular-nums">{record.recordDate}</TableCell>
                      <TableCell className="font-medium">{record.materialName}</TableCell>
                      <TableCell className="text-muted-foreground">{record.specModel}</TableCell>
                      <TableCell className="text-right tabular-nums font-semibold">{record.quantity}</TableCell>
                      <TableCell>{record.unit}</TableCell>
                      <TableCell className="text-muted-foreground">{record.supplier}</TableCell>
                      <TableCell className="text-muted-foreground text-xs max-w-[200px] truncate">{record.remark ?? '-'}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={cn(
                          record.source === 'ocr' ? 'bg-[hsl(210_85%_95%)] text-[hsl(210_85%_48%)]' : 'bg-accent text-accent-foreground',
                        )}>
                          {SOURCE_LABELS[record.source] ?? record.source}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{record.creator}</TableCell>
                      <CanRole roles={['admin']} fallback={null}>
                        <TableCell className="text-right">
                          <Button
                            size="sm"
                            variant="ghost"
                            disabled={actionLoading}
                            onClick={() => openDeleteDialog({ type: 'single', id: record.id })}
                            className="text-muted-foreground hover:text-[hsl(4_75%_52%)] hover:bg-[hsl(4_70%_96%)]"
                          >
                            <Trash2 className="size-3.5" />
                          </Button>
                        </TableCell>
                      </CanRole>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          {total > 0 && (
            <div className="flex items-center justify-between px-4 py-3 border-t">
              <p className="text-sm text-muted-foreground">共 {total} 条，第 {page}/{totalPages} 页</p>
              <div className="flex items-center gap-2">
                <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p: number) => p - 1)}>
                  <ChevronLeft className="size-4" />上一页
                </Button>
                <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage((p: number) => p + 1)}>
                  下一页<ChevronRight className="size-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {selectedIds.size > 0 && (
        <CanRole roles={['admin']} fallback={null}>
          <div className="fixed bottom-0 left-0 right-0 z-40 bg-card border-t shadow-lg">
            <div className="max-w-[1400px] mx-auto px-6 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Checkbox checked={true} onCheckedChange={() => setSelectedIds(new Set())} />
                <span className="text-sm text-foreground">
                  已选择 <span className="font-semibold text-primary">{selectedIds.size}</span> 条记录
                </span>
              </div>
              <Button
                variant="outline"
                size="sm"
                disabled={actionLoading}
                onClick={() => openDeleteDialog({ type: 'batch', ids: Array.from(selectedIds) })}
                className="text-[hsl(4_75%_52%)] border-[hsl(4_75%_52%)] hover:bg-[hsl(4_70%_96%)]"
              >
                <Trash2 className="size-3.5 mr-1" />批量删除
              </Button>
            </div>
          </div>
        </CanRole>
      )}

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget?.type === 'single'
                ? '确认删除该条数据记录吗？'
                : `确认删除已选中的 ${deleteTarget?.type === 'batch' ? deleteTarget.ids.length : 0} 条记录吗？`}
              删除后数据不可恢复。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={actionLoading}>取消</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              disabled={actionLoading}
              className="bg-[hsl(4_75%_52%)] hover:bg-[hsl(4_75%_42%)] text-white"
            >
              确认删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>新增数据记录</DialogTitle>
            <DialogDescription>填写物料信息后添加到数据总表</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="col-span-2 space-y-1.5">
              <label className="text-sm font-medium">日期 <span className="text-destructive">*</span></label>
              <Input type="date" value={addForm.recordDate} onChange={(e) => setAddForm({ ...addForm, recordDate: e.target.value })} />
            </div>
            <div className="col-span-2 space-y-1.5">
              <label className="text-sm font-medium">物料名称 <span className="text-destructive">*</span></label>
              <Input placeholder="请输入物料名称" value={addForm.materialName} onChange={(e) => setAddForm({ ...addForm, materialName: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">规格型号</label>
              <Input placeholder="请输入规格型号" value={addForm.specModel} onChange={(e) => setAddForm({ ...addForm, specModel: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">数量</label>
              <Input type="number" value={addForm.quantity} onChange={(e) => setAddForm({ ...addForm, quantity: Number(e.target.value) })} />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">单位</label>
              <Input placeholder="如：个、箱、kg" value={addForm.unit} onChange={(e) => setAddForm({ ...addForm, unit: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">供应商</label>
              <Input placeholder="请输入供应商" value={addForm.supplier} onChange={(e) => setAddForm({ ...addForm, supplier: e.target.value })} />
            </div>
            <div className="col-span-2 space-y-1.5">
              <label className="text-sm font-medium">备注</label>
              <Input placeholder="请输入备注信息" value={addForm.remark ?? ''} onChange={(e) => setAddForm({ ...addForm, remark: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddDialogOpen(false)} disabled={actionLoading}>取消</Button>
            <Button onClick={handleAdd} disabled={actionLoading}>确认添加</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default DataMasterPage;
