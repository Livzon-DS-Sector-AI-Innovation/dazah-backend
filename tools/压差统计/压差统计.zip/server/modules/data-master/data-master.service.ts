import { Injectable, Inject, NotFoundException, Logger } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { dataMaster } from '@server/database/schema';
import { eq, and, gte, lte, desc, asc, count, inArray, ilike } from 'drizzle-orm';
import type {
  PaginatedResponse,
  DataMasterItem,
  DataMasterQuery,
  CreateDataMasterRequest,
  BatchCreateDataMasterRequest,
  DataMasterExportData,
  DeleteDataMasterResponse,
} from '@shared/api.interface';

@Injectable()
export class DataMasterService {
  private readonly logger = new Logger(DataMasterService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(query: DataMasterQuery): Promise<PaginatedResponse<DataMasterItem>> {
    const page = query.page ?? 1;
    const pageSize = query.pageSize ?? 20;
    const offset = (page - 1) * pageSize;

    const conditions = [];
    if (query.materialName) conditions.push(ilike(dataMaster.materialName, `%${query.materialName}%`));
    if (query.supplier) conditions.push(ilike(dataMaster.supplier, `%${query.supplier}%`));
    if (query.startDate) conditions.push(gte(dataMaster.recordDate, query.startDate));
    if (query.endDate) conditions.push(lte(dataMaster.recordDate, query.endDate));
    if (query.source) conditions.push(eq(dataMaster.source, query.source));

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const [items, totalResult] = await Promise.all([
      this.db
        .select()
        .from(dataMaster)
        .where(whereClause)
        .orderBy(desc(dataMaster.recordDate), asc(dataMaster.materialName))
        .limit(pageSize)
        .offset(offset),
      this.db
        .select({ count: count() })
        .from(dataMaster)
        .where(whereClause),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);

    const mappedItems: DataMasterItem[] = items.map((item) => ({
      id: item.id,
      recordDate: item.recordDate,
      materialName: item.materialName,
      specModel: item.specModel,
      quantity: Number(item.quantity),
      unit: item.unit,
      supplier: item.supplier,
      remark: item.remark,
      source: item.source as DataMasterItem['source'],
      creator: item.creator,
      createdAt: item.createdAt.toISOString(),
    }));

    return { items: mappedItems, total };
  }

  async create(userContext: { userId?: string; userName?: string }, dto: CreateDataMasterRequest): Promise<{ id: string; success: boolean }> {
    const userName: string = userContext?.userName ?? userContext?.userId ?? '';
    const result = await this.db
      .insert(dataMaster)
      .values({
        recordDate: dto.recordDate,
        materialName: dto.materialName,
        specModel: dto.specModel ?? '',
        quantity: String(dto.quantity ?? 0),
        unit: dto.unit ?? '',
        supplier: dto.supplier ?? '',
        remark: dto.remark ?? null,
        source: dto.source ?? 'manual',
        creator: userName,
      })
      .returning({ id: dataMaster.id });

    if (result.length === 0) {
      throw new Error('插入失败');
    }
    return { id: result[0].id, success: true };
  }

  async batchCreate(userContext: { userId?: string; userName?: string }, dto: BatchCreateDataMasterRequest): Promise<{ successCount: number; failCount: number }> {
    const userName: string = userContext?.userName ?? userContext?.userId ?? '';
    let successCount = 0;
    let failCount = 0;

    for (const item of dto.items) {
      try {
        await this.db.insert(dataMaster).values({
          recordDate: item.recordDate,
          materialName: item.materialName,
          specModel: item.specModel ?? '',
          quantity: String(item.quantity ?? 0),
          unit: item.unit ?? '',
          supplier: item.supplier ?? '',
          remark: item.remark ?? null,
          source: item.source ?? 'manual',
          creator: userName,
        });
        successCount++;
      } catch (err) {
        this.logger.error(`Batch insert failed: ${JSON.stringify(err)}`);
        failCount++;
      }
    }

    return { successCount, failCount };
  }

  async getExportData(query: DataMasterQuery): Promise<DataMasterExportData[]> {
    const conditions = [];
    if (query.materialName) conditions.push(ilike(dataMaster.materialName, `%${query.materialName}%`));
    if (query.supplier) conditions.push(ilike(dataMaster.supplier, `%${query.supplier}%`));
    if (query.startDate) conditions.push(gte(dataMaster.recordDate, query.startDate));
    if (query.endDate) conditions.push(lte(dataMaster.recordDate, query.endDate));
    if (query.source) conditions.push(eq(dataMaster.source, query.source));

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const items = await this.db
      .select()
      .from(dataMaster)
      .where(whereClause)
      .orderBy(asc(dataMaster.recordDate), asc(dataMaster.materialName));

    return items.map((item) => ({
      id: item.id,
      recordDate: item.recordDate,
      materialName: item.materialName,
      specModel: item.specModel,
      quantity: Number(item.quantity),
      unit: item.unit,
      supplier: item.supplier,
      remark: item.remark,
      source: item.source,
      creator: item.creator,
      createdAt: item.createdAt.toISOString(),
    }));
  }

  async remove(id: string): Promise<{ success: boolean }> {
    const result = await this.db
      .delete(dataMaster)
      .where(eq(dataMaster.id, id))
      .returning({ id: dataMaster.id });

    if (result.length === 0) {
      throw new NotFoundException('记录不存在');
    }
    return { success: true };
  }

  async batchRemove(ids: string[]): Promise<DeleteDataMasterResponse> {
    if (!ids || ids.length === 0) {
      return { successCount: 0, failCount: 0, success: true };
    }

    const result = await this.db
      .delete(dataMaster)
      .where(inArray(dataMaster.id, ids))
      .returning({ id: dataMaster.id });

    const successCount = result.length;
    const failCount = ids.length - successCount;

    this.logger.log(`Batch delete: ${successCount} succeeded, ${failCount} failed`);
    return { successCount, failCount, success: true };
  }
}
