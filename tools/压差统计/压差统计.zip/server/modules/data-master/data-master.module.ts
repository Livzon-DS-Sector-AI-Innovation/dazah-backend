import { Module } from '@nestjs/common';
import { DataMasterController } from './data-master.controller';
import { DataMasterService } from './data-master.service';

@Module({
  controllers: [DataMasterController],
  providers: [DataMasterService],
  exports: [DataMasterService],
})
export class DataMasterModule {}
