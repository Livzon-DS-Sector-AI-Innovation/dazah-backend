import { Controller, Get, Post, Delete, Param, Query, Body, Req } from '@nestjs/common';
import { NeedLogin, CanRole } from '@lark-apaas/fullstack-nestjs-core';
import { DataMasterService } from './data-master.service';
import type {
  PaginatedResponse,
  DataMasterItem,
  DataMasterQuery,
  CreateDataMasterRequest,
  BatchCreateDataMasterRequest,
  DataMasterExportData,
  DeleteDataMasterResponse,
} from '@shared/api.interface';

@Controller('api/data-master')
export class DataMasterController {
  constructor(private readonly dataMasterService: DataMasterService) {}

  @Get()
  @NeedLogin()
  async list(
    @Query('materialName') materialName?: string,
    @Query('supplier') supplier?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
    @Query('source') source?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<PaginatedResponse<DataMasterItem>> {
    const query: DataMasterQuery = {
      materialName,
      supplier,
      startDate,
      endDate,
      source,
      page: page ? parseInt(page, 10) : 1,
      pageSize: pageSize ? parseInt(pageSize, 10) : 20,
    };
    return this.dataMasterService.list(query);
  }

  @Post()
  @NeedLogin()
  async create(
    @Req() req: { userContext: { userId?: string; userName?: string } },
    @Body() dto: CreateDataMasterRequest,
  ): Promise<{ id: string; success: boolean }> {
    return this.dataMasterService.create(req.userContext, dto);
  }

  @Post('batch')
  @NeedLogin()
  async batchCreate(
    @Req() req: { userContext: { userId?: string; userName?: string } },
    @Body() dto: BatchCreateDataMasterRequest,
  ): Promise<{ successCount: number; failCount: number }> {
    return this.dataMasterService.batchCreate(req.userContext, dto);
  }

  @Get('export')
  @NeedLogin()
  async getExportData(
    @Query('materialName') materialName?: string,
    @Query('supplier') supplier?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
    @Query('source') source?: string,
  ): Promise<DataMasterExportData[]> {
    const query: DataMasterQuery = {
      materialName,
      supplier,
      startDate,
      endDate,
      source,
    };
    return this.dataMasterService.getExportData(query);
  }

  @Delete(':id')
  @NeedLogin()
  @CanRole(['admin'])
  async remove(@Param('id') id: string): Promise<{ success: boolean }> {
    return this.dataMasterService.remove(id);
  }

  @Post('batch-delete')
  @NeedLogin()
  @CanRole(['admin'])
  async batchRemove(@Body() dto: { ids: string[] }): Promise<DeleteDataMasterResponse> {
    return this.dataMasterService.batchRemove(dto.ids);
  }
}
